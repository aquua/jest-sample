package io.searchbox.core.search.facet;

/**
 * @author ferhat
 */
public abstract class Facet {

    protected String name;

    public String getName() {
        return name;
    }
    
    
}
